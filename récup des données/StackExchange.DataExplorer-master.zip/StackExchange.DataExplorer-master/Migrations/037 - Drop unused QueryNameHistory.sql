if OBJECT_ID('QueryNameHistory') is not null
	drop table QueryNameHistory