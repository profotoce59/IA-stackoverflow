-- TODO script to port it ... 

--if OBJECT_ID('SavedQueris') = 1 
--	drop table SavedQueries