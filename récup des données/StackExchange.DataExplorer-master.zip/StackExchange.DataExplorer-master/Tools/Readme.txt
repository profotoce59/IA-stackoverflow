You can use So Slow to load up the creative commons data dumps: http://blog.stackoverflow.com/category/cc-wiki-dump/ 

Just decompress the 7Z file using: http://www.7-zip.org/ , point so-slow at it and set up the connection string

The source for so slow is at: http://github.com/SamSaffron/So-Slow