﻿Debugging - in the project properties, under Debug tab -> Start Options -> Command line arguments:

--tier=local --sites="Data Source=.;Initial Catalog=Sites.Database;Integrated Security=True" --migrationPath="..\..\..\StackOverflow.Migrations"