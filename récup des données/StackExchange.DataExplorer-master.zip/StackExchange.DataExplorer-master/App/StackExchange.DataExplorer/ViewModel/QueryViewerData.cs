﻿using StackExchange.DataExplorer.Models;

namespace StackExchange.DataExplorer.ViewModel
{
    public class QueryViewerData
    {
        public Revision Revision { get; set; }
        public QuerySetVoting QuerySetVoting { get; set; }
    }
}