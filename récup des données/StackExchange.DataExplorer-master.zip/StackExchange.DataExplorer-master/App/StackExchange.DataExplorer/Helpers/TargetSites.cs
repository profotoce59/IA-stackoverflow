﻿namespace StackExchange.DataExplorer.Helpers
{
    public enum TargetSites
    {
        Current = 0, 
        AllSites = 1,
        AllMetaSites = 2,
        AllNonMetaSites = 3,
        AllMetaSitesButMSE = 4,
        AllNonMetaSitesButSO = 5
    }
}