﻿namespace StackExchange.DataExplorer.Helpers
{
    public enum ChangeAction
    {
        Update,
        Insert,
        Delete
    }
}