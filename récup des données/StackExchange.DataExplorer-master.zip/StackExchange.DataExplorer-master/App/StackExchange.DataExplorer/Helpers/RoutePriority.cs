﻿namespace StackExchange.DataExplorer.Helpers
{
    public enum RoutePriority
    {
        Low = 0,
        Default = 1,
        High = 2
    }
}