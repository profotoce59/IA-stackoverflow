﻿namespace StackExchange.DataExplorer.Helpers
{
    public class CaptchaResponse
    {
        public bool Success { get; set; }
    }
}