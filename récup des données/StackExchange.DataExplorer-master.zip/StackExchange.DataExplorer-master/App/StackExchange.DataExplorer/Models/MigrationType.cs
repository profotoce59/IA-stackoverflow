﻿namespace StackExchange.DataExplorer.Models
{
    public enum MigrationType
    {
        Normal = 1,
        Saved = 2
    }
}