﻿namespace StackExchange.DataExplorer.Models
{
    public enum VoteType
    {
        Favorite = 1
    }
}